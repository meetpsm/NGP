// MATHEMATICAL OPERATIONS ON STRINGS
#include<string>
#include<cstring>
#include<iostream>

class string
{
	char *p;
	int len;
   public:
	string() {len = 0; p = 0;} 			// create null string 
	string(const char * s);			// create string from arrays
	string(const string & s);			// copy constructor
	~ string(){delete p;}				// destructor

	// + operator
	friend string operator+(const string &s, const string &t);
	
	// <= operator
	friend int operator<=(const string &s, const string &t);
	friend void show(const string s);
};
string :: string(const char *s)
{
	len = strlen(s);
	p = new char[len+1];
	strcpy(p,s);
}

string :: string(const string & s)
{
	len = s.len;
	p = new char[len+1];
	strcpy(p,s.p);
}

// overloading + operator 
string operator+(const string &s, const string &t)
{
	string temp;
	temp.len = s.len + t.len;
	temp.p = new char[temp.len+1];
	strcpy(temp.p,s.p);
	strcat(temp.p,t.p);
	return(temp);
}

// overloading <= operator
int operator<=(const string &s, const string &t)
{
	int m = strlen(s.p);
	int n = strlen(t.p); 
	
	if(m <= n) return(1);
	
	else return(0);
}
void show(const string s)
{
	std :: cout << s.p;
}

int main()
{
	string s1 = "New ";
	string s2 = "York ";
	string s3 = "Delhi ";
	string t1,t2,t3;
	t1 = s1;
	t2 = s2;
	t3 = s1+s3;
	
	std :: cout << "\nt1 = "; show(t1);
	std :: cout << "\nt2 = "; show(t2);
	std :: cout << "\n";
	std :: cout << "\nt3 = "; show(t3);
	std :: cout << "\n\n";
	if(t1 <= t3)
	{
		show(t1);
		std :: cout << " Smaller than ";
		show(t3);
		std :: cout << "\n";
	}
	else
	{
		show(t3);
		std :: cout << "Smaller than ";
		show(t1);
		std :: cout << "\n";
	}
	
	return 0;
}


// PRINTING A STRING
#include <iostream>							// include header file
using namespace std;
int main()
{
	cout << "Python is better than C and C++ \n"; 		// C++ statement
	return 0;
}									// End of example



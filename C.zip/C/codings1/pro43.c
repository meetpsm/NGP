// TO PREPARE AND PRINT SALES REPORT
#include<stdio.h>
main()
{
	int i,price[10],pid[10],qty[10],n;
	int total[10],comm[10]

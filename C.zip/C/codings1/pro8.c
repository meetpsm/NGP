// TO FIND THE SUM AND REVERSE OF THR GIVEN NUMBER 
#include<stdio.h>
main()
{
	unsigned long int a,num,sum = 0,rnum = 0,rem;
	printf("\nEnter the number...");
	scanf("%ld",&num);
	a = num;
	while(num!=0)
	{
		rem = num%10;
		sum = sum+rem;
		rnum = rnum*10+rem;
		num = num/10;
	}
	printf("\nThe sum of the digits of %ld is %ld \n",a,sum);
	printf("\nThe reverse number of the %ld is %ld",a,rnum);
	if(a==rnum)
		printf("\nThe given number is a palindrome\n");
	else
		printf("\nThe given number is not a palindrome\n");
}

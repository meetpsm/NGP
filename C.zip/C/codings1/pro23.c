// TO FIND THE SMALLEST AND LARGEST OF THE GIVEN ARRAY
#include<stdio.h>
main()
{
	int a[100],i,small,large,no;
	printf("\nIn how many numbers you want to find : \n");
	scanf("%d",&no);
	
	printf("\nEnter the elements of the array : \n");
	for(i = 0;i<no;i++)
		scanf("%d",&a[i]);
	printf("\nThe elements of the array : \n");
	for(i = 0;i<no;i++)
		printf("\n%d",a[i]);
	small = a[0];
	large = a[0];
	for(i=1;i<no;i++)
	{
		if(a[i]>large)
			large = a[i];
		else if(a[i]<small)
			small = a[i];
	}
	printf("\nThe Largest of the given array is %d\n",large);
	printf("\nThe Smallest of the given array is %d\n",small);
}

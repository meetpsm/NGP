// TO COUNT NUMBER OF VOWELS,CONSONENTS, DIGITS, SPACES AND OTHER SPECIAL CHARACTER IN A LINE OF TEXT
#include<stdio.h>
#include<ctype.h>
void main()
{
	char txt[80];
	int nv = 0, nc = 0, nd = 0,ns = 0, no = 0;
	void input(char line[],int *pv, int *pc, int *pd, int *ps, int *po);
	printf("Enter the text \n");
	scanf("%[^\n]",txt);
	input(txt,&nv,&nc,&nd,&ns,&no);
	printf("\nNo. of Vowels : %d",nv);
	printf("\nNo. of Consonents : %d",nc);
	printf("\nNo. of Digits : %d",nd);
	printf("\nNo. of Spaces : %d",ns);
	printf("\nNo. of Other Characters : %d\n",no);
}
void input(char txt[],int *pv, int *pc, int *pd, int *ps, int *po)
{
	char c;
	int i = 0;
	while((c = toupper(txt[i]))!='\0')
	{
		if(c == 'A'||c == 'E' || c == 'I' || c == 'O' || c == 'U')
		++ *pv;
		else if(c >= 'A' && c <= 'Z')
		++ *pc;
		else if(c >= '0' && c <= '9')
		++ *pd;
		else if(c == ' ' || c == '\t')
		++ *ps;
		else
		++ *po;
		++i;
	}
}


//STRING CONCATENATION
#include<stdio.h>
main()
{
	char str1[10],str2[10],str3[40];
	int i,j;	
	printf("Enter the two string : ");
	scanf("%s%s",str1,str2);
	for(i=0;str1[i]!='\0';i++)
	{
		str3[i]=str1[i];
	}
		for(j=0;str2[j]!='\0';j++)
		{
			str3[i]=str2[j];
			i++;
		}
	str3[i]='\0';
	printf("Concatenated string is : %s\n",str3);
}


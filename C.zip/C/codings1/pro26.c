// TO FIND WHETHER THE GIVEN STRING IS PALLINDROME OR NOT
#include<stdio.h>
#include<stdlib.h>
main()
{
	int len = 0,i,j;
	char name[25];
	printf("Enter the string : ");
	scanf("%s",name);
	while(name[len]!='\0')
		len++;
	printf("%d",len);
	for(i=0,j=len-1;i<len/2;i++,j--)
	{
		if(name[i]!=name[j])
		{
			printf("\nThe given string is not a palindrome\n"); 
			exit(0);
		}
	}
	printf("\nThe given string is a palindrome\n");
}

// FACTORIAL USING RECURSION
#include<stdio.h>
void main()
{
	int a,f;
	printf("Enter the Number : ");
	scanf("%d",&a);
	printf("The Factorial of %d = %d",a,rec(a));
}
rec(int x)
//int f;
{
	if(x == 1)
		return(1);
	else
		f = x*rec(x-1);
	return(f);
}


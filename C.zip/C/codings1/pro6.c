// CONVERT THE CELCIUS INTO FAHRENTEIET
#include<stdio.h>
main()
{
	float cel,faren;
	printf("Enter the celcius value...");
	scanf("%f",&cel);
	faren = (1.8 * cel) + 32;
	printf(" The fahrenteiet value of the given %f celcius value is %f",cel,faren);
}

#include<stdio.h>
main()
{
	char p[] = "Hello World!";
	char p = "vector";
	printf("%s\n",p);
}


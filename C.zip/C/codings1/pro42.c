//PROGRAM TO FIND SUBSTRING OF THE GIVEN STRING
#include<stdio.h>
main()
{
	char mainstr[50],substr[50];
	int count,pos,i,j,len,num;
	printf("Enter the main string : ");
	gets(mainstr);
	for(len = 0;mainstr[len] != '\0'; len++);
	printf("\nIt's length is : %d \n",len);
	printf("\nStarting position of substring? ");
	scanf("%d",&pos);
	printf("\nNumber of characters in substring? ");
	scanf("%d",&count);
	if(pos <= 0 || count <= 0 || pos > len)
		printf("\nExtracted string is EMPTY \n");
	else
	{
		if(pos+count-1>len)
		{
			printf("\nCharacters to be extracted exceed length \n");
			num = len-pos+1;
		}
		else
		num = count;
	j = 0;
		for (i=--pos;i<=pos+num-1;i++)
		{
			substr[j]=mainstr[i];
			j++;
		}	
	substr[j]='\0';
	printf("\nSubstring of is : %s\n",substr);
	}
}

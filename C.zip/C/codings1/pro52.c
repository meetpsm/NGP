// TO MAINTAIN STUDENT DATA BASE USING STRUCTURE
#include<stdio.h>
typedef struct std
{
	int rno;
	char name[10];
	int marks;
}
student;
student s[10];
void main()
{
	int i,n;
	printf("Enter Upper Limit : " );
	scanf("%d",&n);
	printf("Enter Student details : \n");
	printf("Enter the roll Number, Name and Mark : \n");
	for(i=1;i <=n ;i++) 
	scanf("%d%s%d",&s[i].rno,s[i].name,&s[i].marks);
	printf("\n");
	printf("Student details are \n\n");
	printf("Roll No \t Name \t\t Marks\n");
	for(i=1;i<=n;i++)
	printf("%d\t\t%s\t\t%d\n",s[i].name,s[i].marks);
}


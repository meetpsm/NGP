#include<stdio.h>
main()
{
	int a=4,b=2;
	a=b<a+b>2;
	printf("%d \n",a);
}

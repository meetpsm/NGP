// BINARY INTO DECIMAL
#include<stdio.h>
main()
{
	int bnum,digit,deci = 0,bin,base = 0;
	printf("\nEnter the binary number : ");
	scanf("%d",&bnum);
	printf("%ls",&bnum);
	bin = bnum;
	while(bnum != 0)
	{
		digit = bnum % 10;
		deci = deci + (digit<<base);
		base = base+1;
		bnum= bnum/10;
	}
	printf("\nThe binary eqivalent of the %d in decimal = %d\n",bin, deci);
}

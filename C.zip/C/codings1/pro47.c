// SWAP THE NUMBER USING POINTER
#include<stdio.h>
main()
{
	int x,y;
	printf("\nEnter the two numbers : ");
	scanf("%d %d",&x,&y);
	printf("\nThe value x and y are, %d,%d\n",x,y);
	display(&x,&y);
	printf("\nAfter swapping : x = %d,y = %d\n",x,y);
}
display(int *a,int *b)
{
	int t;
	t = *a;
	*a = *b;
	*b = t;
}

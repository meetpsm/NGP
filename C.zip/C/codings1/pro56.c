// ACCESSING THE STRING USING THE POINTER VARIABLE
#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
	char name[10];
	char *i;
	printf("\nEnter your Name ");
	getc(name);
	i = name;
	printf("\nYour Name is ");
	while(*i!='\0')
	{
		printf("%c",*i);
		i++;
	}
}


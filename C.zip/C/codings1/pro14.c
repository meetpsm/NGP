// TO FIND THE LARGEST OF THE THREE NUMBERS
#include<stdio.h>
main()
{
	int x,y,z,big;
	printf("Enter the Three numbers : ");
	scanf("%d %d %d",&x,&y,&z);
	big = x;
	if(y>big)
		big = y;
	if(z>big)
		big = z;
	printf("Biggest number is %d\n",big);
}

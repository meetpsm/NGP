// TRANSPOSE OF THE GIVEN MATRIX
#include<stdio.h>
main()
{
	int i,j,a[25][25],row,col;
	printf("\nEnter the number of rows and column of matrix : ");
	scanf("%d%d",&row,&col);
	printf("\nEnter the elements of the matrix : ");
	for(i=0;i<row;i++)
	for(j=0;j<col;j++)
		scanf("%d",&a[i][j]);
	printf("The given matrix \n");
	for(i=0;i<row;i++)
	{
		//printf("\n");
		for(j=0;j<col;j++)
		printf("\t%d",a[i][j]);
	}
	printf("\nThe transpose of the given matrix is..\n");
	for(i=0;i<row;i++)
	{
		printf("\n");
		for(j=0;j<col;j++)
		printf("\t%d",a[j][i]);
	}
}

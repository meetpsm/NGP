// MENU DRIVEN PROGRAM
#include<stdio.h>
main()
{
	int num,o,fact = 1,i;
	while(1)
	{
		printf("Enter the number : ");
		scanf("%d",&num);
		printf("\nChoose one of the option given below");
		printf("\n 1.Factorial of the given number \n 2.Prime number or not \n 3.Odd or Even \n 4.Exit\n");
		printf("\nEnter your choice : ");
		scanf("%d",&o);
		switch(o)
		{
			case 1:
				for(i=1;i<=num;i++)
				fact = fact*i;
				printf("The factorial of %d is %d\n",num,fact);
				break;
			case 2:
				i = 2;
				while(i<=num-1)
				{
					if(num%i==0)
					{
						printf("The given number is not a prime number\n");
						break;
					}
						i++;
				}
				if(i == num)
					printf("The given number is a prime number\n");
				break;
			case 3:
				if(num%2==o)
					printf("The given number is Even number\n");
				else 
					printf("The given number is Odd number\n");
				break;
			default:
			exit(0);
		}
	}
}

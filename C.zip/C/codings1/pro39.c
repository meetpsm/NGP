// TO INSERT AN ELEMENT INTO THE VECTOR
#include<stdio.h>
main()
{	
	int i,k,n,pos;
	float a[50],item;
	printf("Size of Array : ");
	scanf("%d",&n);
	printf("\nEnter Array Elements : ");
	for(i=0;i<n;i++)
		scanf("%f",&a[i]);
	printf("\nEnter New Element to be Inserted : ");
		scanf("%f",&item);
	printf("\nEnter Position of Insertion : ");
		scanf("%d",&pos);
		n++;
		for(k=n;k>=pos;k--)
			a[k] = a[k-1];
		a[--pos] = item;
			printf("\nArray of Elements after insertion : \n");
		for(i=0;i<n;i++)
			{
				printf("%10.0f",a[i]);
			}
			printf("\n");
}

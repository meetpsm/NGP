// ASCENDING AND DESCENDING ORDER OF THE GIVEN NUMBERS
#include<stdio.h>
main()
{
	int num[100],no,i,j,a;
	printf("Enter Upper Limit.... \n");
	scanf("%d",&no);
	printf("Enter the numbers : ");
	for(i=0;i<no;i++)
		scanf("%d",&num[i]);
		for(i=0;i<no-1;i++)
		{
			for(j=i+1;j<no;j++)
			{
				if(num[i]<num[j])
				{
					a=num[i];
					num[i]=num[j];
					num[j] = a;
				}
			}
		}
	printf("\n The descending order of the given numbers : \n");
	for(i = 0;i<no;i++)
		printf("\n%d",num[i]);
	printf("\n The ascending order of the given numbers : \n");
	for(j=no-1;j>=0;j--)
		printf("\n%d\n",num[j]);
}

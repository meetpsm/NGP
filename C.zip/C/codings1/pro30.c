// REVERSE THE STRING USING RECURSION 
#include<stdio.h>
main()
{
	int len;
	void rev();
	printf("Enter the string length : ");
	scanf("%d",&len);
	printf("\n%d",len);
	printf("\n");
	rev(len);
	printf("\n");
}
void rev(len)
int len;
{
	char c;
	if(len==1)
	{
		c = getchar();
		c = getchar();
		putchar(c);
	}
	else
	{
		c = getchar();
		c = getchar();
		rev(--len);
		putchar(c);
	}
return;
}

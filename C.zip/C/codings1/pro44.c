// FUNCTIONS WITH ARGUMENTS BUT NO RETURN VALUES
#include<stdio.h>
main()
{
	int a,b;
	printf("Enter two numbers : ");
	scanf("%d%d",&a,&b);
	add(a,b);
}
add(int a,int b)
{
	int c;
	c = a+b;
	printf("\nThe addition of %d and %d is %d\n",a,b,c);
}

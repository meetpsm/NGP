// TO CHECK WHETHER TE GIVEN MATRIX IS AN UPPER TRIANGULAR OR NOT
#include<stdio.h>
main()
{
	int i,j,a[10][10],m,n,flag=1;
	printf("Enter the order of the matrix (m,n) : ");
	scanf("%d%d",&m, &n);
	printf("\nEnter the matrix row wise : \n");
	for(i=0;i<m;i++)
		for(j=0;j<n;j++)
			scanf("%d",&a[i][j]);
	for(i=0;i<m;i++)
		for(j=0;j<n;j++)
		{		
			if(a[i][j]!=0)
			//printf("\n\nThe given matrix is not an upper triangular");
			flag = 0;
			break;
		}
	printf("\nThe given matrix is not an upper triangular\n");
	if(flag)	
		printf("\nThe given matrix is an upper triangular\n");
}


// TO FIND THE FACTORIAL OF THR GIVEN NUMBER
#include<stdio.h>
main()
{
	int fact = 1,i,num;
	printf("Enter the Number : ");
	scanf("%d",&num);
	for(i = 1; i <= num;i++)
	{
		fact = fact*i;
	}
	printf("The factorial of %d is %d",num,fact);
}

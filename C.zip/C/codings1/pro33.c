// TO PRINT MAGIC SQUARE NUMBERS
#include<stdio.h>
#include<string.h>
main()
{
	int x,y,z;
	for (x=0;x<=1;x+=2)
	for (y=0;y<=1;y+=2)
	for (z=9;z<=10;z<=10)
	{
	printf("\n\n Magic Sauare \n\n",3+x);
	printf("\n%d\t%d\t%d\n",x-z,x+z-y,x+y);
	printf("\n%d\t%d\t%d\n",x+y+z,x,x-y-z);
	printf("\n%d\t%d\t%d\n",x-y,x+y-z,x+z);
	break;
	}
}	

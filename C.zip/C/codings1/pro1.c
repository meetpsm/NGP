// RADIUS OF THE CIRCLE & CIRCUMFERENCE OF THR CIRCLE
#include<stdio.h>
main()
{
	int rad,area,circum;
	printf("\nEnter the radius of the circle : ");
	scanf("%d",&rad);
	area = 3.14*rad*rad;
	circum = 2*3.14*rad;
	printf("\nArea = %d",area);
	printf("\nCircumference = %d\n",circum);
}



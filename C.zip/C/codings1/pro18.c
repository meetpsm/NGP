// TO PRINT THE FOLLOWING TRIANGLE
// 1  
// 1 2
// 1 2 3
// 1 2 3 4
// 1 2 3 4 5
#include<stdio.h>
main()
{
	int i, j, n;
	printf("Number of lines : ");
	scanf("%d", &n);
	printf("\n\n\n");
	for (i=1;i<=n;i++)
	{
		for (j=1;j<=i;j++)
		printf("%-2d",j);
		printf("\n\n");
	}
}

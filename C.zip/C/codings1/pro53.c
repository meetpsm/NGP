// TO WRITE A PROGRAM FOR NESTED STRUCTURES, THE TWO STRUCTURES ARE DECLARED WITHIN A SINGLE STRUCTURE
#include<stdio.h>
struct dob
{
	int dd;
	int mm;
	int yy;
}dt;

struct address
{
	char st[20];
	char city[20];
}add;

struct student
{
	int rno;
	char name[20];
	struct dob dt; 
	struct address add;
}std;

void main()
{
	
	printf("Enter the students details  \n");
	
	printf("Enter the roll number and Name : ");
	
	scanf("%d%s",&std.rno,std.name);
	
	printf("Enter student's Date of birth : ");
	
	scanf("%d%d%d",&std.dt.dd,&std.dt.mm,&std.dt.yy);
	
	printf("Enter student's address details : ");
	
	scanf("%s%s",std.add.st,std.add.city);
	
	printf("\n");
	
	printf("The Students details are : ");
	
	printf("Roll number \t Name \t\t DOB \t\t Adress\n");
	
	printf("%d\t%s\t\t",std.rno,std.name);
	
	printf("%d%d%d\t",std.dt.dd,std.dt.mm,std.dt.yy);
	
	printf("%s%s",std.add.st,std.add.city);

	
}


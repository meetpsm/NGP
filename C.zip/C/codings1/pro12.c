// TO FIND THE GIVEN NUMBER IS PRIME OR NOT
#include<stdio.h>
main()
{
	int num,i=2;
	printf("Enter the number : ");
	scanf("%d",&num);
	while(i<=num-1)
	{
		if(num%i==0)
		{
			printf("The given number is not a prime number\n");
			break;
		}
	i++;
	}
	if(i==num)
		printf("The given number is a prime\n");
}

// TO FIND THE DETERMINE OF 2x2 MATRIX
#include<stdio.h>
main()
{
	int a[2][2],d,i,j;
	printf("Enter any 2x2 matrix : ");
	for (i=0;i<2;i++)
	for (j=0;j<2;j++)
		scanf("%d",&a[i][j]);
	d=a[0][0]*a[1][1] - a[0][1] * a[1][0];
	printf("-----------------\n");
	printf("Matrix\n");
	printf("-----------------\n");
	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		printf("%-4d",a[i][j]);
	printf("\n");
	}
	printf("-----------------\n");
	printf("\nThe determinant value is %-4d\n",d);
}

// TO FIND WHETHER A YEAR IS LEAP YEAR OR NOT
#include<stdio.h>
main()
{
	int ye;
	printf("Enter the year : ");
	scanf("%d", &ye);
	if (ye%4==0)
		printf("It is a Leap year \n");
	else
		printf("It is not a Leap year \n");
}

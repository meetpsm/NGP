// TO READ 'n' NUMBERS AND FIND THE MAXIMUM AND THE MINIMUM
#include<stdio.h>
main()
{
	int table[50],i,cnt,max,min;
	//clrscr();
	printf("\nEnter the number of elements in the array : ");
	scanf("%d",&cnt);
	printf("Enter the elements : ");
	for (i=1;i<=cnt; i++)
		scanf("%d",&table[i]);
		max = min = table[i];
	for (i=2;i<=cnt;i++)
	{
		if (max<table[i])
		max = table[i];
		else if(min>table[i])
		min = table[i];
	}
	printf("Maximum value = %d\n",max);
	printf("Minimum value = %d\n",min);
}

// TO CHECK WHEATHER THE FILE IS JEPG OR NOT
//#include<e.h>
#include<stdio.h>
#include<string.h>
int main(int argc, char * argc[])
{
	if(argc != 2)
	{
		return 1;
	}
		FILE * file = fopen(argc[1],"r");
		if (file == NULL)
		{
		return 1;
		}
			unsigned char bytes[3];
			fread(bytes,3,1,file);
			if(bytes[0] == 0xff 
			&& bytes[1] == 0xds
			&& bytes[1] == 0xff)
			{
				printf("This image is a JEPG file \n");
			}
			else
			{
				printf("NO it's not!! \n");
			}
}


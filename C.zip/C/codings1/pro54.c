// TO WRITE A PROGRAM FOR PASSING STRUCTURE MEMBERS AS A PARAMETERS TO THE FUNCTION
#include<stdio.h>
typedef struct stud
{
	int rno;
	char name[20];
	int marks;
}
student;
student st;
void disp_rec(int,char[],int);
void main()
{
	char ch;
	char ans;
	do
	{
		printf("Enter Student Details \n");
		printf("Enter Rollno,Name and mark : ");
		scanf("%d%s%d",&st.name,st.marks);
		printf("Add more (y/n) \n ");
		ans = getch();
	}
	while(ans == 'y');
}
void disp_rec(int r,char n[],int m)
{
	printf("The Details are \n");
	printf("%d\t%s\t\t%d\n",r,n,m);
}


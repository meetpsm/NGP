// TO FIND THE ADDITION OF TWO MATRIXES
#include<stdio.h>
main()
{
	int a[25][25],b[25][25],c[25][25],i,j,m,n;
	printf("Enter the Rows and Columns of two matrixes \n");
	scanf("%d %d",&m,&n);
	printf("\n Enter the elements of A matrix : ");
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
			scanf("%d",&a[i][j]);
	}
	printf("\n Enter the elements of B matrix : ");
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
			scanf("%d",&a[i][j]);
	}
	printf("\nThe elements of A matrix");
	for(i=0;i<m;i++)
	{
		printf("\n");
		for(j=0;j<n;j++)
		printf("\t%d",a[i][j]);
	}
	printf("\n The elements of B matrix");
	for(i=0;i<m;i++)
	{
		printf("\n");
		for(j=0;j<n;j++)
			printf("\t%d",b[i][j]);
	}
	printf("\n The addition of two matrixes");
	for(i=0;i<m;i++)
	{
		printf("\n");
		for(j=0;j<n;j++)
		{
			c[i][j] = a[i][j]+b[i][j];
		}
	}
}

// TO WRITE A SIMPLE MENU DRIVEN CALCULATOR PROGRAM USING SWITCH STATEMENT
#include<stdio.h>
//#include<conio.h>
void main()
{
	int a,b,c,n;
	//clrscr();
	printf("   --- MENU ---\n");
	printf("1 ADDITION \n");
	printf("2 SUBTRACTION \n");
	printf("3 MULITIPLICATION \n");
	printf("4 DIVISION \n");
	printf("0 EXIT \n");
	printf("Enter your choice : ");
	scanf("%d",&n);
	if(n<=4&n>0)
	{
		printf("Enter two numbers : ");
		scanf("%d%d",&a,&b);
	}
	switch(n)
	{
	case 1:
		c = a+b;
		printf("Addition : %d\n",c);
		break;
	case 2:
		c = a-b;
		printf("Subtraction : %d\n",c);
		break;
	case 3:
		c = a*b;
		printf("Multiplication : %d\n",c);
		break;
	case 4:
		c = a/b;
		printf("Division : %d\n",c);
		break;
	case 0:
		//exit(0);
		break;
	default:
		printf("Invalid operation");
	}
}

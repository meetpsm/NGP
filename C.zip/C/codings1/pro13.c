// TO FIND THE SIZE OF THE DATES
#include<stdio.h>
main()
{
	int i = 10;
	float f = 25.005;
	char name[] = "welcome";
	printf("\nThe size of integer is %d",sizeof(i));
	printf("\nThe size of float is %d",sizeof(f));
	printf("\nThe size of character is %d\n",sizeof(name));
}
	

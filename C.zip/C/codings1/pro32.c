// CONVERT THE LOWER CASE TO UPPER CASE
#include<stdio.h>
main()
{
	int i=0;
	char str[100];
	printf("Enter the string : ");
	scanf("%s",str);
	while(str[i]!='\0')
	{
		printf("%c ",toupper(str[i]));
		i++;
	}
}


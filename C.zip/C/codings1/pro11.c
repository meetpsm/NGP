// CONSTRACT PASCAL TRIANGLE
#include<stdio.h>
main()
{
	int noline,i,j,temp;
	printf("Enter the number of the lines");
	scanf("%d",&noline);
	for(i=1;i<=noline;i++)
	{
		for(j=1;j<=noline-i;j++)
		printf("              ");
		temp = i;
		for(j=1;j<=i;j++);
		temp = temp-2;
		for(j=1;j<i;j++)
			printf("%4d",temp--);
			printf("\n\n");
	}
	printf("\n");
}

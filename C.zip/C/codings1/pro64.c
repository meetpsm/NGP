#include<stdio.h>
int array[]={1,2,3,4,5,6,7,8};
#define SIZE (sizeof(array)/sizeof(int))
main()
{
	if(1<=SIZE) printf("1\n");
	else printf("2\n");
}


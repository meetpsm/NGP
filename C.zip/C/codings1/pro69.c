#include<stdio.h>
main()
{
	enum_tag(left = 10, right, front = 100, back);
	printf("%d,%d,%d",left,right,front,back);
}



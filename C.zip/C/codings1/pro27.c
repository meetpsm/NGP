 // TO COUNT NO. OF VOWLES AND CONSONANTS IN A GIVEN STRING
#include<stdio.h>
main()
{
	int v=0, c=0, i=0;
	char str[25];
	printf("Enter the string : ");
	scanf("%s",str);
	while(str[i]!='\0')
	{
		switch(str[i])
		{
			case 'A':
			case 'E':
			case 'I':
			case 'O':
			case 'U':
			case 'a':
			case 'e':
			case 'i':
			case 'o':
			case 'u':
			v++;
			break;
		default:
			c++;
		}
	i++;
}
printf("\nThe number of vowels is %d",v);
printf("\nThe number of consonants is %d\n",c);
}

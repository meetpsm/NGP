// TO WRITE A PROGRAM FOR ELECTRICITY BILL PREPARATION
#include<stdio.h>
//include<conio.h>
void main()
{
	int present,previous,consumed,srlno;
	char name[20],rcptno[10],billmonth[15],date[12];
	float total;
	//clrscr()
	printf("Enter Serial Number & Receipt Number : ");
	scanf("%d%s", &srlno,rcptno);
	
	printf("Enter Bill Month and Date : ");
	scanf("%s%s",billmonth,date);
	
	printf("Present and Previous readings : ");
	scanf("%d%d", &present, &previous);
	
	consumed = present-previous;
	if(consumed >= 200)
	total = consumed*2.50;
	else 
	total = consumed*1.50;
	printf("\n\t\t ELECTRICITY BILL \n");
	printf("\t\t---------------------------\n");
	printf("SC No.%d\t\t\t Receipt.No:%s\n",srlno,rcptno);
	printf("Bill Month : %s\t\t Date : %s\n", billmonth,date);
	printf("Total cost for consumed %d unit is Rs : %f",consumed,total);
	//getch();
}

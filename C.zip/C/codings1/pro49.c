// TO CALCULATE SIMPLE INTEREST
#include<stdio.h>
int main()
{
	float p = 1, r = 2, t = 3;
	float psi = (p*t*r)/100;
	printf("Simple interest = %f\n",psi);
}


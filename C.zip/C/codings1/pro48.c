// TO PRINT PRIME NUMBERS FROM 1 TO N
#include<stdio.h>
#include<stdbool.h>
bool isprime(int n)
{
	if(n == 1 || n == 0)
		return false;
	for (int i = 1; i <= n/2; i++)
		{
		if(n % i == 0)
			return false;
		}
		return true;
}
int main()
{
	int N = 50;
	for(int i = 1; i <= N; i++)
	{
		if (isprime(i))
			printf("%d \n",i);
	}
}
		

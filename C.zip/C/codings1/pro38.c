// TO DELETE THE DUPLICATES IN A VECTOR
#include<stdio.h>
main()
{
	int i,j,k,n, num,flag = 0;
	float a[50];
	printf("Size of vector? ");
	scanf("%d",&n);
	num = n;
	printf("\nEnter Vector Elements? \n");
	for(i=0;i<n;i++)
		scanf("%f",&a[i]);
			for(i=0;i<n-1;i++)
				for(j=i+1;j<n;j++)
				{
					if(a[i] == a[j])
							{
							n=n-1;
							for(k=j;k<n;k++)
								a[k]=a[k+1];
								flag=1;
								j--;
							}
				}
	if(flag==0)
printf("\nNo duplicates found in vector \n");
	else
	{
		if((num-n)==1)
		{
			printf("\nVectors has only one deplicates \n");
			printf("Vectors after deleting duplicates : \n");
			for(i=0;i<n;i++)
				printf("%d6.2f",a[i]);
		}
		else
		{
			printf("\nVector has %d duplicates \n\n",num-n);
			printf("Vector after deleting duplicates : \n");
			for (i=0;i<n;i++)
				printf("%6.2f\n",a[i],"\n");
		}
	}
}


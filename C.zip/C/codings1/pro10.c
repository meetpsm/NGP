// SINE SERIES 
#include<stdio.h>
#include<math.h>
int main()
{
	int no,i;
	float x,a,sum,b;
	printf("Enter the Number : \n");
	scanf("%f %d",&x,&no);
	b = x;
	x = x*3.141/180;
	a = x;
	sum = x;
	for(i=1; i<no+1;i++)
	{
	a = (a*pow((double)(-1),(double)(2*i-1))*x*x)/(2*i*(2*i+1));
	sum = sum + a;
	}
	printf("Sin(%f) value is %f\n",b,sum);
}

// ASCENDING AND DESCENDING ORDER OF THE GIVEN ARRAY
#include<stdio.h>
main()
{
	int num[100],no,i,j,a;
	printf("Size of array : ");
	scanf("%d",&no);
	printf("\nArray elements : ");
	for(i=0;i<no;i++)
		scanf("%d",&num[i]);
		for(i=0;i<no-1;i++)
		{
			for(j=i+1;j<no;j++)
			{
				if(num[i]<num[j])
				{
					a=num[i];
					num[i]=num[j];
					num[j] = a;
				}
			}
		}
		{	
			printf("\nThe descending order of the Array : ");
				for(i = 0;i<no;i++)
					printf("%d ",num[i]);
		}
		{
			printf("\n\nThe ascending order of the Array : ");
				for(j=no-1;j>=0;j--)
					printf("%d ",num[j]);
		}
		{
			printf("\n");
		}
}
	

#include<stdio.h>
main()
{
	int*ptr = (int*)malloc(sizeof(int));
	*ptr=4;
	printf("%d \n",(*ptr)+++*ptr++);
}

// TO USING THE POINTERS AND ARRAYS
#include<stdio.h>
void main()
{
	int x[10],i,n;
	printf("Enter upper limit : ");
	scanf("%d",&n);
	printf("Enter numbers \n");
	for(i=1;i<=n;i++)
	scanf("%d",&x[i]);
	printf("\n");
	printf("The number are\n");
	for(i=1;i<=n;i++)
	printf("At address of %u the values is %d\n",(x+i),*(x+i));
	//getch();
}


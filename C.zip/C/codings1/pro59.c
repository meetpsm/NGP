// TO INTRODUCING THE FILE PREMITIVES, SUCH AS FOPEN, FCLOSE, FPRINTF
#include<stdio.h>
void main()
{
	FILE *fp;
	int rno;
	char name[20];
	fp = fopen("std.dat","w");
	if(fp == NULL)
	{
		printf("File Opening error\n");
		exit(1);
	}
	printf("Enter Roll Number & Name : \n");
	scanf("%d%c",&rno,&name);
	fprintf(fp,"%d%s",&rno,name);
	fclose(fp);
}

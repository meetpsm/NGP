// INSERTING AN ELEMENTS INTO THE VECTOR
#include<stdio.h>
main()
{
	int a[100],no,i,pos,item;
	printf("\nEnter the size of the matrix : ");
	scanf("%d",&no);
	printf("\nEnter the elements of the matrix : ");
	for(i = 0;i<no;i++)
		scanf("%d",&a[i]);
	printf("\nEntered elements of the matrix is : \n");
	for(i = 0;i<no;i++)
		printf("\n%d",a[i]);
	printf("\nEnter the element and its position in the array : ");
	scanf("%d/n%d",&item,&pos);
	no++;
	for(i=no;i>=pos;i--)
	a[i] = a[i-1];
	a[-pos] = item;
	printf("\n");
	printf("\nArray after the insertion\n");
	for(i=0;i,no;i++)
	printf("\n%d",a[i]);
}

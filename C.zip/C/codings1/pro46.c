// TO ARRANGE NAMES IN ALPHABETICAL ORDER
#include<stdio.h>
#include<string.h>
main()
{
	char names[20][20],temp[10],c;
	int i,j,k,n = 0;
	printf("Enter the Names, to stop type keyword END : \n");
	scanf("%s",names[n]);
	while(strcmp(names[n],"END")>0)
	{
		n++;
		scanf("%s",names[n]);
	}
	printf("\n");
	for(i=0;i<n;i++)
		printf("%10",names[i]);
	printf("\n");
	printf("\n");
	printf("Number of Names : %d\n",n);
	for(i=0;i<n-1;i++)
		for(j=i+1;j<n;j++)
		{
			if(strcmp(names[i],names[j])>0)
			{
				strcpy(temp,names[i]);
				strcpy(names[i],names[j]);
				strcpy(names[j],temp);
			}
		}
	printf("After Sorting the Names are : \n");
	for(i = 0;i < n;i++)
		printf("%10s",names[i]);
	printf("\n");
}

// TO ILLUSTRATE HOW THE VARIABLE CAN BE ACCESSED BY POINTER
#include<stdio.h>
void main()
{
	int r;
	float a,*b;
	printf("Enter Radius : ");
	scanf("%d",&r);
	printf("\n");
	a = 1.14*r*r;
	b = &a;
	printf("Value of a %f\n",a);
	printf("Address of a %u\n",&a);
	printf("Address of b %u\n",b);
	printf("Value of b 5f\n",*b);
}


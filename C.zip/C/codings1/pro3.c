// TO FIND THE VALUE OF COSINE
#include<stdio.h>
#include<math.h>
int main()
{
	float x,a,sum,temp;
	int i,no = 20,mul;
	printf("Enter the value of thr x");
	scanf("%f",&x);
	a = x;	
	x = x*3.1412/180;
	temp = 1; sum = 1;
	for (i = 1; i < no + 1; i ++)
	{
		temp = temp * pow ((double)(-1),(double)(2*i-1))*x*x/(2*i*(2*i-1));
		sum = sum + temp;
	}
	printf("\n The cosine value of %f is %f",a,sum);
}

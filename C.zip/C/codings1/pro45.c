// TO FIND THE FACTORIAL OF THE GIVEN NUMBER
#include<stdio.h>
main()
{
	int num,a;
	printf("Enter the number : " );
	scanf("%d",&num);
	a = recur(num);
	printf("\nThe Factorial of %d is %d\n",num,a);
}
recur(int no)
{
	int fact = 1;
	if(no==1)
		return(1);
else
	fact = no*recur(no-1);
}

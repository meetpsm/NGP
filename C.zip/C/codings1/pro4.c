// EXPONETIAL SERIES
#include<stdio.h>
main()
{
	float x, temp = 1, sum = 1; int i,no;
	printf("Enter the numbers");
	scanf("%f %d",&x,&no);
	for (i = 1;i<no;i++)
	{
		temp = temp*x/i;
		sum = sum+temp;
	}
	printf("Exponent of x is %f/n",sum);
}

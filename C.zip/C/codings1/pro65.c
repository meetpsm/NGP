#include<stdio.h>
main()
{
	int ptr[] = {1,2,23,6,5,6,};
	printf("%d \n",&ptr[3]-&ptr[0]);
}


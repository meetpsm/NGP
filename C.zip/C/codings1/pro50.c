// TO CALCULATE COMPOUND INTEREST 
#include<stdio.h>
#include<math.h>
int main()
{
	double Principal = 10000;
	double Rate = 5;
	double Time = 2;
	double Amount = Principal *(pow (1 + Rate / 100),Time);
	double CI = Amount - Principal;
	printf("Compound interest is : ",CI);
}


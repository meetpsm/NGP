// TO PRINT THE FIBBONACI  SERIES UPTO GIVEN NUMBERS 
#include<stdio.h>
main()
{
	int num,fib = 0, a=0, b=1,i;
	printf("Enter the number: ");
	scanf("%d",&num);	
	printf("\nFIBBONACI SERIES\n");
	if(num == 0)
		printf("0");
	else
	{
		for(i = 0; i<num; i++)
		{
			fib = fib + a;
			a = b;
			b = fib;
			printf("%d\t",fib);
		}
	}
}

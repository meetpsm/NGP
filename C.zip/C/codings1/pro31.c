// FIND THE SUM AND AVERAGE OF THE GIVEN NUMBERS
#include<stdio.h>
main()
{
	int a[100],i,no,sum=0;
	float avg = 0;
	printf("\nEnter the number of elements : ");
	scanf("%d",&no);
	printf("\nEnter the numbers : ");
	for(i = 0;i<no;i++)
	{
		scanf("%d",&a[i]);	
		sum = sum + a[i];
	}
	avg = (float)sum/no;
	printf("\nsum = %d \n");
	printf("\naverage = %f \n",sum,avg);
}

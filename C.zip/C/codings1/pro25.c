// MULTIPLICATION OF TWO MATRIX
#include<stdio.h>
main()
{
	int a[25][25],b[25][25],c[25][25],i,j,k,r,s;
	int m,n;
	printf("\nEnter the Rows and Columns of A matrix : ");
	scanf("%d %d",&m,&n);
	printf("\nEnter the Rows and Columns of B matrix : ");
	scanf("%d %d",&r,&s);
	if(m!=r)
		printf("\nThe matrix cannot multiplied\n ");
	else
	{
		printf("\nEnter the elements of A matrix : ");
		for(i=0;j<m;i++)
		{
			for(j=0;j<n;j++)
			scanf("\t%d",&a[i][j]);
		}
		printf("\nEnter the elements of B matrix : ");
		for(i = 0;i<m;i++)
		{
			for(j=0;j<n;j++)
			scanf("\t%d",&b[i][j]);
		}
		printf("\nThe elements of A matrix : ");
		for(i=0;i<m;i++)
		{
			printf("\n");
			for(j = 0; i<m; i++)
			printf("\t%d",a[i][j]);
		}
		for(i=0;i<m;i++)
		{
			printf("\n");
			for(j=0; j<n;j++)
			{
				c[i][j] = 0;
				for(k=0;k<m;k++)
				c[i][j] = c[i][j] + a[i][k]*b[k][j];
			}
		}
	}

printf("\nThe multiplication of two matrixes\n : ");
for(i=0;i<m;i++)
	{
	printf("\n");
	for(j=0;j<n;j++)
	printf("\t%d",c[i][j]);
	} 
}

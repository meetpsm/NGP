// TO FIND THE STRING LENGTH OF THE STRING 
#include<stdio.h>
#include<string.h>
main()
{
	char str1[50],str2[] = "WELCOME";
	int len;
	printf("Enter the string : ");
	scanf("%s",str1);
	printf("\nThe string length of %s is %d",str1,strlen(str1));
	printf("\nThe concatenation string length is %d and its string is %s \n",strlen(str1),strcat(str1,str2));
}

// TO PRINT TRIANGLE OF NUMBERS
#include<stdio.h>
main()
{
	int i, j, k, l, n;
	printf("Type N-no of lines in triangle : \n");
	scanf("%d",&n);
	l = 1;
	for (i=1, j=n-i; i<=n; i++, j--)
	{
		for (k=1; k<=j; k++)
			printf("              ");
		for (k=1; k<=l; k++)
			printf("         %d",i);
		printf("\n");
		l+=2;
	}
}

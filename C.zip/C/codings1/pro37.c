//TO DEMONSTRATE MACROS WITH ARGUMENTS
#include<stdio.h>
#define square(x) ((x)*(x))
#define loop(index,max) for(index = 0; index <max; index++)
#define max(x,y) (((x)>(y))? (x):(y))
main()
{
	int a,b,i=0,n,large,vec[10],sq[10];
	printf("Program to compute : \n");
	printf("1. Largest element in the array.\n");
	printf("2. Square of each array element.\n\n");
	printf("Enter the size of the array : ");
	scanf("%d",&n);
	printf("\nEnter the elements of the array : ");
	loop(i,n) 
		scanf("%d",&vec[i]);
	loop(i,n)
		printf("%5d",vec[i]);
	large = 0;
	loop(i,n)
	{
		sq[i] = square(vec[i]);
		large = max(large,vec[i]);
	}
	printf("\n\nLargest array element is : %5d",large);
	printf("\nElement Square \n");
	printf("   ------------\n");
	loop(i,n)
		printf("%5d %8d\n",vec[i],sq[i]);
}
